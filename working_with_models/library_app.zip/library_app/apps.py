from django.apps import AppConfig


class LibraryAppConfig(AppConfig):
    name = 'library_app'
