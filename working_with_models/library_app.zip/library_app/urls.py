from django.urls import path
from . import views
from working_with_models.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static
from . views import *

urlpatterns = [

path('', Myview.as_view(),),
    path('create/',Employee_create.as_view() ),
    path('list/', Employee_list.as_view() ),
    path('<pk>/',Employee_Detail.as_view()),
   path('<pk>/update',Employee_Update.as_view()),
   path('<pk>/delete/',Employee_Delete.as_view())



]
#DataFlair
if DEBUG:
    urlpatterns += static(STATIC_URL, document_root = STATIC_ROOT)
    urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)